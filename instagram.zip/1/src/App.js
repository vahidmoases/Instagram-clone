import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/login"; // Assuming Login is already imported
import { lazy } from "react";
import * as ROUTES from './constants/routes'
import './styles/app.css'
import Signup from "./pages/signup";
import NotFound from "./pages/not-found";
import Dashboard from "./pages/dashboard";
import useAuthListener from "./hooks/use-auth-listener";
import UserContext from "./context/user";




export default function App()  {

  const { user } = useAuthListener()

  // const login = lazy(() => import('./pages/login')); // Lazy loading Login component
  // const SignUp = lazy(() => import('./pages/signup')); // Lazy loading Login component
  // const notfound = lazy(() => import('./pages/not-found')); // Lazy loading Login component

  return (
    <UserContext.Provider value={{ user }} >
    <BrowserRouter>
      <Routes>
        <Route exact path={ROUTES.LOGIN} element={<Login />} />
        <Route exact path={ROUTES.SIGN_UP} element={<Signup />} />
        <Route exact path={ROUTES.DASHBOARD} element={<Dashboard />} />
        <Route path={ROUTES.ANY} element={<NotFound />} /> 
      </Routes>
    </BrowserRouter>
    </UserContext.Provider>
  );
}


