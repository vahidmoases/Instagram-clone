import { createContext } from "react";

const FirebaseContext = createContext(null)

export default FirebaseContext