import useUser from "../../hooks/use-users"
import Suggestions from "./suggestions"
import User from './user'


export default function Sidebar() {
    const { 
        user : { fullName, username, userID }
     } = useUser()
    

    
    return(
        <div className="p-4">
            <User username={username} fullName={fullName} /> 
            <Suggestions userID={userID} />
        </div>
    )
}