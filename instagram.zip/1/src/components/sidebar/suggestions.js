export default function Suggestions(){
    return <p>i am suggestions</p>
}