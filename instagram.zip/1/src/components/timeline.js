export default function Timeline(){
    return(
        <p>I am the timeline</p>
    )
}